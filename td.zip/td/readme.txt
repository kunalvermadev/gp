1.extract it  to your location like D:/extensions
2.open  chrome --->goto  extensions-->load unpacked and  select the extension "extension" folder.
3.done.